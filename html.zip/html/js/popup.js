$(function () {
	//script for popups
	$('a.show_popup').click(function () {
		$('div.'+$(this).attr("rel")).fadeIn(500);
		$("body").append("<div id='overlay'></div>");
		$('#overlay').show().css({'filter' : 'alpha(opacity=80)'});
		return false;
	});

	$('a.show_popup2').click(function () {
		$('div.'+$(this).attr("rel")).fadeIn(500);
		$("body").append("<div id='overlay'></div>");
		$('#overlay').show().css({'filter' : 'alpha(opacity=80)'});
		return false;
	});

	$('a.close').click(function () {
		$(this).parent().fadeOut(200);
		$('#overlay').remove('#overlay');
		return false;
	});
});	


document.addEventListener("click", function(e) {
	let actMenu = document.querySelector('.reg_form');
	let actMenu2 = document.querySelector('.reg_form2');
	console.log(actMenu);
	console.log(e.target);
	console.log(actMenu.contains(e.target));
	console.log(actMenu2.contains(e.target));
	if ((!actMenu.contains(e.target)) && (!actMenu2.contains(e.target))){
			$('.popup').fadeOut(200);
	}
  });