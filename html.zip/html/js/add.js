var select = document.getElementById('select');
var option;

for (var i=0; i<select.options.length; i++) {
  option = select.options[i];
  if (option.value == 's2') {
    console.log("teacher")
     option.selected = true;
     return;
  } 
}