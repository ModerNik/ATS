function show() {
	setTimeout(() => error.style.visibility = "visible", 5000);
};

btn.addEventListener("click", show);