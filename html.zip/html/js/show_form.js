function show() {
	add_smth.style.visibility = "visible";
	btn_add.style.visibility = 'hidden';
};

btn_add.addEventListener("click", show);