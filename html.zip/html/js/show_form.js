$( document ).ready(function(){

	$("#btn1").click(
		function(){
			btn1.style.visibility = 'hidden';
			btn2.style.visibility = 'hidden';
			hidden.style.visibility = 'visible';
		}
	);

	$("#btn2").click(
		function(){
			btn1.style.visibility = 'hidden';
			btn2.style.visibility = 'hidden';
			hidden2.style.visibility = 'visible';
		}
	);

	$("#plans").click(
		function(){
			plans.style.visibility = 'hidden';
			hidden.style.visibility = 'visible';
		}
	);
})