<?php
	echo json_encode($row);
?>