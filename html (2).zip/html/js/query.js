$(document).ready(function() {
  function find() {
    // Stop form from sending request to server
    e.preventDefault();
    $.ajax({
      method: "POST",
      url: "C:\Users\stata\Desktop\Project Ozarenie\Server\server.py",
      dataType: "json",
      async: false,
      onResponse,
      data: {
        'input': $('input').val()
      },
      success: function(data) {
        console.log(data);
      },
      error: function(er) {
        console.log(er);
      }
    });
    //$.post("C:\Users\stata\Desktop\Project Ozarenie\Server\server.py",{data:$("#in1").val()},onResponse);
    function onResponse(data){
      $("#in2").text(data);
      console.log(data);
    }
  }
});