arrowTop.onclick = function() {
window.scrollTo(pageXOffset, 0);
};

window.onscroll = function(){
	if (window.pageYOffset > 0.5*document.documentElement.clientHeight){
		arrowTop.classList.add('shown');
	} else {
		arrowTop.classList.remove('shown');
	}
}