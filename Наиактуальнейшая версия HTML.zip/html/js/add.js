var $add = document.getElementsByClassName('add')[0];
var $form = document.getElementsByClassName('content')[0];
$add.addEventListener('click', function(event) {
  var $input = document.createElement('input');
  $input.type = 'text';
  $input.placeholder = '�������';
  $input.placeholder = 'name_student';
  $input.class = 'name_student';
  $input.classList.add('amount');
  $content.insertBefore($input, $add);
});


//action = "add_plan"//