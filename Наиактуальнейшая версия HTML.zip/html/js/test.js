var c=0;
		function Engine(num){
			if (num == 0) 
			{c++}
		else
		 {var obj = document.getElementById('Txt'+(num));obj.innerHTML = " "+(num)}}

		 function ca(){   
			var obj = document.getElementById('Txt');
			obj.innerHTML =(x);        
		}
			
			
		function show(divid){
		if(document.getElementById(divid).style.display=="none")
        {
		document.getElementById(divid).style.display="inline";
		}
		else
		{
		document.getElementById(divid).style.display="none";
		}
		}   

		function otv(){var score=c; x=score 
        {
        if (score<=100)
        {
		document.getElementById(divid="otv1").style.display="inline"; 
		}
		 
		{if (score>=100 && score<=110){
		document.getElementById(divid="otv2").style.display="inline";
		}
		 
		{if (score>=110 && score<=200){
		document.getElementById(divid="otv3").style.display="inline";
		}
		 
		{if (score>=210 && score<=300){
		document.getElementById(divid="otv4").style.display="inline";
		}
		}}}}}